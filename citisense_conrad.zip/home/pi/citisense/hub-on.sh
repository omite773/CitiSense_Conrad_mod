echo '1-1' | sudo tee /sys/bus/usb/drivers/usb/bind #power on USB
